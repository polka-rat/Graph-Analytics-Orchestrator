# Course Project: Graph Analytics Orchestrator

An autonomous, multi-agent graph analytics orchestrator built in Python. The system dynamically discovers algorithm tools from the class registry, curates reliable implementations via automated testing, and answers natural-language graph queries through multi-step reasoning, entity disambiguation, and subgraph chaining[cite: 4, 16, 32].

---

## 1. Team Members & Roles

| Member | Student ID | Project Role | Core Responsibilities |
| :--- | :--- | :--- | :--- |
| **Member 1** | ID_MEMBER_1 | **Planner** | Prompt engineering, query classification (clarification/unsupported), step-budgeting. |
| **Member 2** | ID_MEMBER_2 | **Executor** | Tool-calling loop, argument parsing, error recovery, and `result_graph_id` chaining. |
| **Member 3** | ID_MEMBER_3 | **Tool Curator** | Automated benchmarking (`curate_tools.py`), registry validation, and tool filtering. |
| **Member 4** | ID_MEMBER_4 | **Evaluation Lead** | Benchmarking accuracy against `public_expected.json`, trace auditing, and error analysis. |
| **Member 5** | ID_MEMBER_5 | **Integration Lead** | CLI runner (`run_queries.py`), repository packaging, and environment verification. |

---

## 2. Environment Setup

### Prerequisites
- Python 3.10 or later[cite: 5, 10]
- Git[cite: 11]

### Installation Steps
1. **Create and activate a virtual environment**:
   - **Windows (Command Prompt / PowerShell)**[cite: 10, 11]:
     ```cmd
     python -m venv .venv
     .venv\Scripts\activate
     ```
   - **Linux / macOS**[cite: 10, 11]:
     ```bash
     python -m venv .venv
     source .venv/bin/activate
     ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt