"""Test suite for node_embedding_similarity."""
from graphkit.testing import load, store

tool = load(__file__)


def test_embedding_ranking_structure():
    s = store()
    out = tool.run(s, graph_id="karate", node="m1", top_k=5)
    assert out["status"] == "ok"
    assert len(out["result"]) == 5
    for item in out["result"]:
        assert "score" in item
        assert "id" in item
        assert "label" in item
        assert -1.0 <= item["score"] <= 1.0


def test_seed_determinism():
    s = store()
    r1 = tool.run(s, graph_id="karate", node="m1", seed=42)
    r2 = tool.run(s, graph_id="karate", node="m1", seed=42)
    assert r1["result"] == r2["result"]


def test_invalid_node_error():
    out = tool.run(store(), graph_id="karate", node="unknown_xyz")
    assert out["status"] == "error"
    assert "lookup_node" in out["error"]


def test_invalid_graph_error():
    out = tool.run(store(), graph_id="nonexistent_graph", node="m1")
    assert out["status"] == "error"


def test_top_k_bounds():
    assert tool.run(store(), graph_id="karate", node="m1", top_k=0)["status"] == "error"
    assert tool.run(store(), graph_id="karate", node="m1", top_k=150)["status"] == "error"