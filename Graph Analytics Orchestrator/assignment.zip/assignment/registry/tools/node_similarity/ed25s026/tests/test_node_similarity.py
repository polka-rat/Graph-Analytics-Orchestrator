"""Test suite for node_similarity."""
from graphkit.testing import load, store, to_networkx

tool = load(__file__)


def test_jaccard_matches_networkx():
    import networkx as nx

    s = store()
    out = tool.run(s, graph_id="karate", node="m1", target_node="m2")
    assert out["status"] == "ok"
    G = to_networkx(s.get("karate"))
    expected = next(nx.jaccard_coefficient(G, [("m1", "m2")]))[2]
    assert abs(out["result"]["jaccard_similarity"] - expected) < 1e-6


def test_ranking_mode_top_k():
    s = store()
    out = tool.run(s, graph_id="karate", node="m1", top_k=5)
    assert out["status"] == "ok"
    assert len(out["result"]) == 5
    for entry in out["result"]:
        assert "score" in entry
        assert "common_neighbors" in entry


def test_determinism():
    s = store()
    r1 = tool.run(s, graph_id="airports", node="MAA", top_k=5)
    r2 = tool.run(s, graph_id="airports", node="MAA", top_k=5)
    assert r1 == r2


def test_invalid_node_error():
    out = tool.run(store(), graph_id="karate", node="missing_node_999")
    assert out["status"] == "error"
    assert "lookup_node" in out["error"]


def test_unknown_parameter_rejected():
    out = tool.run(store(), graph_id="karate", node="m1", unexpected_param="invalid")
    assert out["status"] == "error"