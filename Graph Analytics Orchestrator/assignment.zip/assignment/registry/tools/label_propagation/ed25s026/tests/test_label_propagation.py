"""Test suite for label_propagation."""
from graphkit.testing import load, store

tool = load(__file__)


def test_registers_valid_subgraph():
    s = store()
    out = tool.run(s, graph_id="karate", top_k=5)
    assert out["status"] == "ok"
    assert out["result_graph_id"] is not None
    # Subgraph must exist in store and be queryable
    sub = s.get(out["result_graph_id"])
    assert sub.number_of_nodes() > 0


def test_all_nodes_partitioned():
    s = store()
    out = tool.run(s, graph_id="karate", top_k=100)
    assert out["status"] == "ok"
    total_nodes_in_communities = sum(item["size"] for item in out["result"])
    g = s.get("karate")
    assert total_nodes_in_communities == g.number_of_nodes()


def test_seed_determinism():
    s = store()
    r1 = tool.run(s, graph_id="karate", seed=10)
    r2 = tool.run(s, graph_id="karate", seed=10)
    assert [c["size"] for c in r1["result"]] == [c["size"] for c in r2["result"]]


def test_invalid_graph_error():
    out = tool.run(store(), graph_id="nonexistent_network")
    assert out["status"] == "error"


def test_top_k_bounds():
    assert tool.run(store(), graph_id="karate", top_k=0)["status"] == "error"
    assert tool.run(store(), graph_id="karate", top_k=101)["status"] == "error"