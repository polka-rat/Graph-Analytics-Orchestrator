"""Tool Curator: Discovers, evaluates, and filters class registry tools.

Scans registry/<tool_name>/<impl_id>/, tests each candidate against the tool
contract and manifest examples using isolated GraphStore instances, and selects
the best implementation for each algorithm into curated_registry/.
"""
from __future__ import annotations

import json
import re
import shutil
import time
from pathlib import Path
from typing import Any

from graphkit.loader import load_manifest, load_tool
from graphkit.store import GraphStore

ROOT = Path(__file__).resolve().parent
CURATED_DIR = ROOT / "curated_registry"


def locate_registry_dir() -> Path:
    """Finds the registry directory across starter folder variants."""
    candidates = [
        ROOT / "registry" / "tools",
        ROOT / "registry",
        ROOT / "tools",
    ]
    for p in candidates:
        if p.is_dir() and any(p.iterdir()):
            subdirs = [d for d in p.iterdir() if d.is_dir()]
            if subdirs:
                return p
    return ROOT / "registry"


def _normalize_output(obj: Any) -> str:
    """Serializes output while normalizing auto-incrementing subgraph IDs (e.g. karate~1 -> karate~X)."""
    text = json.dumps(obj, sort_keys=True, default=str)
    return re.sub(r"~[0-9]+", "~X", text)


def test_candidate(tool_dir: Path) -> tuple[bool, float, str]:
    """Evaluates an implementation on loading, manifest execution, and determinism.

    Returns:
        (is_valid, average_runtime_seconds, status_reason)
    """
    try:
        manifest = load_manifest(tool_dir)
        tool = load_tool(tool_dir)
    except Exception as exc:
        return False, 999.0, f"Load/Import error: {type(exc).__name__}: {exc}"

    examples = manifest.get("examples", [])
    if not isinstance(examples, list) or not examples:
        examples = [{"graph_id": "karate"}]

    durations: list[float] = []

    for idx, ex in enumerate(examples, 1):
        if not isinstance(ex, dict):
            continue

        # Run 1 on an isolated store instance
        store1 = GraphStore()
        t0 = time.perf_counter()
        try:
            res1 = tool.call(store1, **ex)
        except Exception as exc:
            return False, 999.0, f"Crashed on example {idx}: {exc}"
        elapsed = time.perf_counter() - t0
        durations.append(elapsed)

        if not isinstance(res1, dict) or res1.get("status") != "ok":
            err_msg = res1.get("error") if isinstance(res1, dict) else "Non-dict return"
            return False, 999.0, f"Returned error on example {idx}: {err_msg}"

        # Test determinism on the first example using a second isolated store instance
        if idx == 1:
            try:
                store2 = GraphStore()
                res2 = tool.call(store2, **ex)
                s1 = _normalize_output(res1.get("result"))
                s2 = _normalize_output(res2.get("result"))
                if s1 != s2:
                    return False, 999.0, "Non-deterministic result on identical inputs"
            except Exception as exc:
                return False, 999.0, f"Determinism rerun failed: {exc}"

    avg_time = sum(durations) / len(durations) if durations else 0.0
    return True, avg_time, "Passed"


def curate_registry() -> None:
    registry_path = locate_registry_dir()
    print(f"Scanning class tool registry at: {registry_path}")

    if CURATED_DIR.exists():
        shutil.rmtree(CURATED_DIR)
    CURATED_DIR.mkdir(parents=True, exist_ok=True)

    algo_folders = [d for d in registry_path.iterdir() if d.is_dir() and not d.name.startswith(".")]

    total_curated = 0
    curation_summary: dict[str, Any] = {}

    for algo_dir in sorted(algo_folders):
        algo_name = algo_dir.name

        candidates = [
            sub for sub in algo_dir.iterdir()
            if sub.is_dir() and (sub / "tool.json").is_file() and (sub / "tool.py").is_file()
        ]

        if not candidates and (algo_dir / "tool.json").is_file() and (algo_dir / "tool.py").is_file():
            candidates = [algo_dir]

        best_candidate: Path | None = None
        best_speed = float("inf")
        eval_logs: list[str] = []

        for candidate in candidates:
            valid, speed, note = test_candidate(candidate)
            eval_logs.append(f"  - {candidate.name}: {note} ({speed:.4f}s)")
            if valid and speed < best_speed:
                best_speed = speed
                best_candidate = candidate

        if best_candidate:
            dest = CURATED_DIR / algo_name
            shutil.copytree(best_candidate, dest)

            m = load_manifest(dest)
            impl_id = m.get("implementation_id", f"{algo_name}.{best_candidate.name}")

            curation_summary[algo_name] = {
                "selected_impl": impl_id,
                "source_path": str(best_candidate),
                "avg_runtime": round(best_speed, 4),
            }
            total_curated += 1
            print(f"[OK] Curated '{algo_name}' -> {impl_id} (avg {best_speed:.4f}s)")
        else:
            print(f"[WARN] No working candidate found for '{algo_name}'")
            for log in eval_logs:
                print(log)

    meta_file = CURATED_DIR / "curation_manifest.json"
    meta_file.write_text(json.dumps(curation_summary, indent=2), encoding="utf-8")
    print(f"\nCompleted. Curated {total_curated} reliable tools into '{CURATED_DIR.name}/'.")


if __name__ == "__main__":
    curate_registry()