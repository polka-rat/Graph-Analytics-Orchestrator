"""Agent execution engine: manages tool calling, strict schema sanitization, and trace logging."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

from graphkit.loader import discover
from graphkit.llm import make_client, model_name
from graphkit.store import GraphStore
from graphkit.trace import Trace

from orchestrator.parser import parse_orchestrator_output
from orchestrator.prompts import build_system_prompt

MAX_CALL_BUDGET = 6


def _sanitize_gemini_schema(manifest: dict[str, Any]) -> dict[str, Any]:
    """Sanitizes tool schemas to be strictly compliant with Google Gemini's OpenAPI parser.

    Removes unsupported keys ('default', 'minimum', 'maximum') that trigger HTTP 400.
    """
    name = manifest.get("name", "tool")
    desc = manifest.get("description", "").split(". ")[0].strip()
    if not desc.endswith("."):
        desc += "."

    raw_params = manifest.get("parameters", {})
    if not isinstance(raw_params, dict):
        raw_params = {"type": "object", "properties": {}}

    clean_props = {}
    for p_name, p_data in raw_params.get("properties", {}).items():
        if not isinstance(p_data, dict):
            continue

        p_type = p_data.get("type", "string")
        if p_type not in ("string", "number", "integer", "boolean", "array", "object"):
            p_type = "string"

        p_desc = p_data.get("description", "").split(". ")[0].strip()

        # Fold defaults and bounds into description so model still knows them
        annotations = []
        if "default" in p_data:
            annotations.append(f"default={p_data['default']}")
        if "minimum" in p_data or "maximum" in p_data:
            annotations.append(f"range=[{p_data.get('minimum', '')}, {p_data.get('maximum', '')}]")
        if annotations:
            p_desc = f"{p_desc} ({', '.join(annotations)})"

        prop_spec: dict[str, Any] = {
            "type": p_type,
            "description": p_desc,
        }

        if "enum" in p_data and isinstance(p_data["enum"], list):
            prop_spec["enum"] = [str(x) for x in p_data["enum"]]

        if p_type == "array" and "items" in p_data and isinstance(p_data["items"], dict):
            prop_spec["items"] = {"type": p_data["items"].get("type", "string")}

        clean_props[p_name] = prop_spec

    # Gemini requires 'required' to be non-empty if present
    req_fields = [r for r in raw_params.get("required", []) if r in clean_props]

    parameters: dict[str, Any] = {
        "type": "object",
        "properties": clean_props,
    }
    if req_fields:
        parameters["required"] = req_fields

    return {
        "type": "function",
        "function": {
            "name": name,
            "description": desc,
            "parameters": parameters,
        },
    }


def _ensure_structured_json(client: Any, model: str, question: str, raw_text: str) -> str:
    """Converts plain natural language answers into the required JSON schema."""
    if "```json" in raw_text or ('"status"' in raw_text and '"answer"' in raw_text):
        return raw_text

    structuring_messages = [
        {
            "role": "system",
            "content": (
                "You are a strict data formatter. Take the natural language answer to the graph question "
                "and convert it into the EXACT required JSON format.\n"
                "Output ONLY a ```json ... ``` block. No conversational text.\n\n"
                "SCHEMA:\n"
                "```json\n"
                "{\n"
                '  "status": "answered" | "clarification_needed" | "unsupported",\n'
                '  "answer_text": "<concise explanation>",\n'
                '  "answer": {\n'
                '    "type": "number" | "boolean" | "node" | "node_list" | "path" | "text",\n'
                '    "value": <extracted_value>,\n'
                '    "ordered": true | false\n'
                "  }\n"
                "}\n"
                "```\n"
                "RULES:\n"
                "- 'number': numeric scalar (e.g. 20058, 2, 0.4324)\n"
                "- 'node': single node ID string (e.g. 'FRA', 'MUC', 'm2')\n"
                "- 'node_list': array of node ID strings. Set 'ordered': true if ranked.\n"
                "- 'path': ordered array of node ID strings (e.g. ['MAA', 'DEL', 'JFK'])\n"
                "- 'boolean': true or false\n"
                "- 'text': empty string \"\" for 'clarification_needed' and 'unsupported'"
            ),
        },
        {
            "role": "user",
            "content": f"Question: {question}\nRaw Answer: {raw_text}",
        },
    ]

    try:
        res = client.chat.completions.create(
            model=model,
            messages=structuring_messages,
            temperature=0.0,
        )
        return res.choices[0].message.content or raw_text
    except Exception:
        return raw_text


class GraphOrchestrator:
    def __init__(self, tools_dir: Path, infra_dir: Path):
        self.store = GraphStore()
        discovered = discover(infra_dir, tools_dir)
        self.tools = {t.name: t for t in discovered}
        self.client = make_client()
        self.model = model_name()
        self.schemas = [_sanitize_gemini_schema(t.manifest) for t in self.tools.values()]

    def run_query(self, query_id: str, question: str, trace_path: Path) -> dict[str, Any]:
        trace = Trace(trace_path)
        trace.question(question)

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": build_system_prompt(self.store)},
            {"role": "user", "content": question},
        ]

        tools_invoked: list[str] = []
        active_subgraph_id: str | None = None

        for _ in range(MAX_CALL_BUDGET):
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    tools=self.schemas if self.schemas else None,
                    temperature=0.0,
                )
            except Exception as api_err:
                # Print server-side detail if 400 Bad Request happens
                if hasattr(api_err, "response") and hasattr(api_err.response, "text"):
                    print(f"\nAPI Error Detail: {api_err.response.text}", file=sys.stderr)
                raise api_err

            msg = response.choices[0].message
            trace.llm_call(self.model, msg)
            messages.append(msg)

            if not msg.tool_calls:
                raw_text = msg.content or ""
                structured_text = _ensure_structured_json(self.client, self.model, question, raw_text)
                trace.final_answer(structured_text)

                return parse_orchestrator_output(
                    query_id=query_id,
                    raw_text=structured_text,
                    tools_used=tools_invoked,
                    trace_path=str(trace_path),
                )

            for call in msg.tool_calls:
                # Clean up any potential leaked commentary tokens
                raw_name = call.function.name
                fn_name = re.sub(r"<\|.*?\|>.*", "", raw_name).strip()
                if fn_name.endswith("commentary"):
                    fn_name = fn_name.replace("commentary", "").strip()

                try:
                    fn_args = json.loads(call.function.arguments) if call.function.arguments else {}
                except Exception as exc:
                    fn_args = {}
                    tool_output = {"status": "error", "error": f"Invalid arguments: {exc}"}
                else:
                    if "graph_id" not in fn_args and active_subgraph_id:
                        fn_args["graph_id"] = active_subgraph_id

                    if fn_name in self.tools:
                        tool_ref = self.tools[fn_name]
                        tools_invoked.append(tool_ref.implementation_id)
                        tool_output = tool_ref.call(self.store, **fn_args)

                        if isinstance(tool_output, dict) and tool_output.get("result_graph_id"):
                            active_subgraph_id = tool_output["result_graph_id"]
                    else:
                        tool_output = {"status": "error", "error": f"Tool '{fn_name}' not available."}

                trace.tool_call(fn_name, fn_args, tool_output)
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "name": fn_name,
                    "content": json.dumps(tool_output, default=str),
                })


        fallback_msg = "Step budget exhausted."
        trace.error(fallback_msg)
        return parse_orchestrator_output(
            query_id=query_id,
            raw_text=fallback_msg,
            tools_used=tools_invoked,
            trace_path=str(trace_path),
        )